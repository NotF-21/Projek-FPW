<?php $__env->startSection('title', "Chat $shopname"); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .chat
        {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .chat li
        {
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 1px dotted #B3A9A9;
        }

        .chat li.left .chat-body
        {
            margin-left: 60px;
        }

        .chat li.right .chat-body
        {
            margin-right: 60px;
        }


        .chat li .chat-body p
        {
            margin: 0;
            color: #777777;
        }

        .panel .slidedown .glyphicon, .chat .glyphicon
        {
            margin-right: 5px;
        }

        .panel-body
        {
            overflow-y: scroll;
            height: 250px;
        }

        ::-webkit-scrollbar-track
        {
            -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
            background-color: #F5F5F5;
        }

        ::-webkit-scrollbar
        {
            width: 12px;
            background-color: #F5F5F5;
        }

        ::-webkit-scrollbar-thumb
        {
            -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
            background-color: #555;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-10">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h2>Chat</h2>
            </div>
            <div class="panel-body">
                <ul class="chat">
                    <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($chat->chat_sender=="customer"): ?>
                            <li class="right clearfix">
                                <div class="chat-body clearfix">
                                    <div class="header">
                                        <small class=" text-muted"><?php echo e(date('F j, Y, g:i a',strtotime($chat->created_at))); ?></small>
                                        <a href="<?php echo e(url("customer/chat/delete/$chat->chat_id")); ?>" class="btn btn-danger btn-fill btn-sm rounded-0" title="Delete"><i class="fa fa-trash"></i></a>
                                        <strong class="pull-right primary-font">Me</strong>
                                    </div>
                                    <p>
                                        <?php echo e($chat->chat_content); ?>

                                    </p>
                                </div>
                            </li>
                        <?php else: ?>
                            <li>
                                <div class="chat-body">
                                    <div class="header">
                                        <strong class="primary-font"><?php echo e($shopname); ?></strong> <small class="pull-right text-muted"><?php echo e(date('F j, Y, g:i a',strtotime($chat->created_at))); ?></small>
                                    </div>
                                    <p>
                                        <?php echo e($chat->chat_content); ?>

                                    </p>
                                </div>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="panel-footer">
                <form action="/customer/chat/send" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="room" value="<?php echo e($room); ?>">
                    <div class="input-group">
                        <input id="btn-input" type="text" class="form-control input-sm" name="content" placeholder="Type your message here..." />
                        <span class="input-group-btn">
                            <button class="btn btn-warning btn-sm" id="btn-chat">
                                Send</button>
                        </span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/customer/chat.blade.php ENDPATH**/ ?>