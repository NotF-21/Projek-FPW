<?php $__env->startSection('title', $shop->shop_name); ?>

<?php $__env->startSection('content'); ?>
    <div class="card rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex flex-column align-items-center text-center p-3 py-4">
                    <span class="font-weight-bold" style="font-size: 24pt">Filter Produk</span>
                </div>
            </div>
            <div class="col-12">
                <form action="/customer/toko=<?php echo e($shop->shop_name); ?>/cari" method="get">
                    <div class="row mt-3 px-3">
                        <div class="col-md-12">
                            <input type="text" name="produk" class="form-control" placeholder="Nama Produk" value="<?php echo e(old('nama', '')); ?>">
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mt-3 px-3">
                        <div class="col-md-6">
                            <input type="text" name="min" class="form-control" placeholder="Minimum Harga">
                            <?php $__errorArgs = ['min'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="max" class="form-control" placeholder="Maksimum Harga">
                            <?php $__errorArgs = ['max'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mt-3 px-3">
                        <div class="col-md-6">
                            <select name="category" id="" class="form-control">
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k->Type_Name); ?>"><?php echo e($k->Type_Name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <select name="stok" id="" class="form-control">
                                <option value="">---</option>
                                <option value="all">Semua Produk</option>
                                <option value="available">Hanya yang Tersedia</option>
                            </select>
                        </div>
                    </div>
                    <div class="mt-3 mb-3 text-center">
                        <button class="btn btn-primary profile-button" type="submit">Search</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if(Session::has('scscart')): ?>
        <label for="" class="text-success"><?php echo e(Session::get('scscart')); ?></label>
    <?php endif; ?>

    <?php $__currentLoopData = $list->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mt-2 px-2">
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card p-3 bg-white mx-4">
                    <div class="about-product text-center mt-2 mb-2"><img src="<?php echo e(asset("storage/imgProduct/product_$p->product_id")); ?>" width="300">
                        <div>
                            <h4><?php echo e($p->product_name); ?></h4>
                            <h6 class="mt-0 text-black-50"><?php echo e($p->product_desc); ?></h6>
                        </div>
                    </div>
                    <div class="stats mt-2">
                        <div class="d-flex justify-content-between p-price"><span>Kategori</span><span><?php echo e($p->type->Type_Name); ?></span></div>
                        <?php if($p->product_stock==0): ?>
                            <div class="d-flex justify-content-between p-price text-danger"><span>Habis !</span></div>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex justify-content-between total font-weight-bold mt-4"><span>Harga</span><span>Rp<?php echo e(number_format($p->product_price,0,',','.')); ?></span></div>
                    <div class="row mt-2">
                        <div class="col-md-2">
                            <?php if($fav[$i][$j]=="yes"): ?>
                                <div id="star_<?php echo e($p->product_id); ?>" class="star" tag="<?php echo e($p->product_id); ?>" token="<?php echo e(Session::token()); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                                    </svg>
                                </div>
                            <?php else: ?>
                                <div id="star_<?php echo e($p->product_id); ?>" class="star" tag="<?php echo e($p->product_id); ?>" token="<?php echo e(Session::token()); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-star" viewBox="0 0 16 16">
                                        <path d="M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z"/>
                                    </svg>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-10">
                            <form action="/customer/cart/add/<?php echo e($p->product_id); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="text" class="form-control mb-2" name="number" id="inlineFormInputName2" placeholder="Jumlah">
                                <?php $__errorArgs = ["number"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <button type="submit" class="btn btn-primary mb-2">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="card rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <span class="font-weight-bold" style="font-size: 24pt">Daftar Review</span>
                </div>
            </div>
            <?php $__currentLoopData = $shop->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-3">
                    <div class="card ml-2" style="width: 90%;">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($review->customer->customer_name); ?></h5>
                            <p><?php for($i=0; $i<$review->review_rating; $i++): ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                                    <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
                                </svg>
                            <?php endfor; ?>
                            </p>
                            <p><?php echo e($review->review_review); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php if(count($cart)): ?>
        <div class="fixed" style="position: fixed; bottom: 0; width:100%; display:flex; justify-content:center;">
            <a href="<?php echo e(url("customer/keranjang")); ?>" class="btn btn-success"><h5>Keranjang <?php echo e(count($cart)); ?></h5></a>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('.star').on('click', function(){
                var id = $(this).attr('tag');
                var token = $(this).attr('token');

                $.ajax({
                    type: "POST",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "<?php echo e(url('customer/favorit/add')); ?>",
                    data: {
                        _token : "<?php echo e(csrf_token()); ?>",
                        id : id,
                    },
                    success: function (response) {
                        var res = JSON.parse(response);
                        var ids = "star_"+id;

                        if (res.act=="del") {
                            document.getElementById(ids).innerHTML = "<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32' fill='currentColor' class='bi bi-star' viewBox='0 0 16 16'><path d='M2.866 14.85c-.078.444.36.791.746.593l4.39-2.256 4.389 2.256c.386.198.824-.149.746-.592l-.83-4.73 3.522-3.356c.33-.314.16-.888-.282-.95l-4.898-.696L8.465.792a.513.513 0 0 0-.927 0L5.354 5.12l-4.898.696c-.441.062-.612.636-.283.95l3.523 3.356-.83 4.73zm4.905-2.767-3.686 1.894.694-3.957a.565.565 0 0 0-.163-.505L1.71 6.745l4.052-.576a.525.525 0 0 0 .393-.288L8 2.223l1.847 3.658a.525.525 0 0 0 .393.288l4.052.575-2.906 2.77a.565.565 0 0 0-.163.506l.694 3.957-3.686-1.894a.503.503 0 0 0-.461 0z'/></svg>";
                        } else if (res.act=="add") {
                            document.getElementById(ids).innerHTML = "<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32' fill='currentColor' class='bi bi-star-fill' viewBox='0 0 16 16'><path d='M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z'/></svg>";
                        }
                    },
                    error:function(xhr, status, error){
                        alert(xhr.responseText);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/customer/toko.blade.php ENDPATH**/ ?>