<?php $__env->startSection('title', 'Daftar Transaksi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <span class="font-weight-bold" style="font-size: 24pt">History Transaksi</span>
                </div>
            </div>
            <div class="col-12">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>#</th>
                        <th>Nomor Nota</th>
                        <th>Tanggal Transaksi</th>
                        <th>Toko</th>
                        <th>Total</th>
                        <th>Detail</th>
                        <th>Status (Apakah Anda sudah menerima pesanan Anda ?)</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($trans->invoice_number); ?></td>
                                <td><?php echo e(date('F j, Y, g:i a',strtotime($trans->trans_date))); ?></td>
                                <td><?php echo e($shops[$key]->shop_name); ?></td>
                                <td>Rp<?php echo e(number_format($trans->trans_total,0,',','.')); ?></td>
                                <td>
                                    <button tag="<?php echo e($trans->invoice_number); ?>" class="btn btn-primary btn-detail">Detail</button>
                                </td>
                                <td>
                                    <?php if($trans->order_status=="waiting"): ?>
                                    Menunggu
                                    <?php elseif($trans->order_status=="confirmed"): ?>
                                    Terkonfirmasi
                                    <?php elseif($trans->order_status=="sent"): ?>
                                    Dalam Pengiriman
                                    <a href="<?php echo e(url("customer/receive/$trans->invoice_number")); ?>" class="btn btn-success">Klik jika sudah menerima pesanan !</a>
                                    <?php elseif($trans->order_status="received"): ?>
                                    Sudah Sampai
                                    <?php else: ?>
                                    Dibatalkan
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <div class="modal" tabindex="-1" id="modalReview">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Review Transaksi</h5>
                </div>
                <div class="modal-body">
                    <p>Pilih rating yang sesuai untuk transaksi ini</p>
                    <form action="/customer/review" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="shop" value="0">
                        <div class="row mt-3 px-3">
                            <div class="col-md-12">
                                <input type="number" max="5" min="0" step="1" name="rating" class="form-control" placeholder="Rating">
                            </div>
                        </div>
                        <div class="row mt-3 px-3">
                            <div class="col-md-12">
                                <input type="text" name="review" class="form-control" placeholder="Review Anda">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary mt-4">Review</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal modalTrans" tabindex="-1" id="modal_<?php echo e($t->invoice_number); ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Detail Transaksi</h5>
                    </div>
                    <div class="modal-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $details[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($detail->product->product_name); ?></td>
                                        <td>Rp<?php echo e(number_format($detail->product->product_price,0,',','.')); ?></td>
                                        <td><?php echo e($detail->product_number); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <p>Promo yang dipakai : <?php if($promo[$key]=="empty"): ?>
                                Tidak ada
                                <?php else: ?>
                                <?php echo e($promo[$key]->promo_name); ?>

                            <?php endif; ?></p>
                        </div>
                        <div class="row">
                            <p>Promo yang dipakai : <?php if($pg[$key]=="empty"): ?>
                                Tidak ada
                                <?php else: ?>
                                <?php echo e($pg[$key]->promo_global_name); ?>

                            <?php endif; ?></p>
                        </div>
                        <div class="row">
                            <p>Voucher yang dipakai : <?php if($voucher[$key]=="empty"): ?>
                                Tidak ada
                                <?php else: ?>
                                <?php echo e($voucher[$key]->voucher_name); ?>

                            <?php endif; ?></p>
                        </div>
                        <button type="button" class="btn btn-danger btn-fill" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $("#modalReview").modal("show");
         $(".btn-detail").on("click", function (e) {
            var id = "#modal_" + $(this).attr("tag");
            $(id).modal("show");
        });
    </script>

    <script>
        <?php if(Session::has('rev')): ?>
            $("input[name=shop]").val("<?php echo e(Session::get('rev')); ?>");
            $("#modalReview").modal("show");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/customer/transaksi.blade.php ENDPATH**/ ?>