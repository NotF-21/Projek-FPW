<?php $__env->startSection('image', url('css/login.jpg')); ?>
<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <h5>Login</h5>
    <?php if(Session::has('Message')): ?>
        <label for="" class="text-danger" style="font-weight: bold"><?php echo e(Session::get('Message')); ?></label>
    <?php endif; ?>
    <form action="#" method="post">
        <?php echo csrf_field(); ?>
        <div class="inputs">
            <input type="text" placeholder="Enter your username" name="username" value="<?php echo e(old('username', '')); ?>">
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="password" placeholder="Enter your password" name="password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>
        <div class="remember-me--forget-password">
            <input type="checkbox" name="" id="" style="display: inline-block">
            <label for="">Remember me</label>
        </div>
        <p>Don't have an account? <br><a style="display: inline; margin-bottom:2%" href="/register/customer">Create Your Account (for customer)</a> <br> <a style="display: inline;" href="/register/shop">Create Your Account (for shop)</a></p>
        <button>Login</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.logreg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/logreg/login.blade.php ENDPATH**/ ?>