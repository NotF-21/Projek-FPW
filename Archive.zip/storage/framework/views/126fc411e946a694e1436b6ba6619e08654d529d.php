<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">List of Products</h4>
                <p class="category">Here you can see all of our registered products, both active and inactive</p>
                <?php if(Session::has('Message')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('Message')); ?></label>
                <?php endif; ?>
                <?php if(Session::has('scsaddp')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scsaddp')); ?></label>
                <?php endif; ?>
                <?php if(Session::has('scsupl')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scsupl')); ?></label>
                <?php endif; ?>
                <?php if(Session::has('scse')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scse')); ?></label>
                <?php endif; ?>
                <?php $__errorArgs = ['namee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['desce'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['pricee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>Key</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Product Stock</th>
                        <th>Product Description</th>
                        <th>Product Type</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->product_name); ?></td>
                                <td><?php echo e($item->product_price); ?></td>
                                <td><?php echo e($item->product_stock); ?></td>
                                <td><?php echo e($item->product_desc); ?></td>
                                <td><?php echo e($item->type->Type_Name); ?></td>
                                <td>
                                    <button value="<?php echo e($item->product_id); ?>" <?php if($item->deleted_at!=null): ?>
                                        disabled
                                    <?php endif; ?> class="btn btn-warning btn-fill btnEdit">Edit Product</button>
                                    <?php if($item->deleted_at==null): ?>
                                        <a href="<?php echo e(url("shop/product/delete/$item->product_id")); ?>" class="btn btn-danger btn-fill">Delete</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url("shop/product/delete/$item->product_id")); ?>" class="btn btn-success btn-fill">Recover</a>
                                    <?php endif; ?>
                                    <button value="<?php echo e($item->product_id); ?>" <?php if($item->deleted_at!=null): ?>
                                        disabled
                                    <?php endif; ?> class="btn btn-primary btn-fill btnUpload">Upload Image</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <p class="category">Here you can download all of the data into an Excel spreadsheet</p>
                <a href="/shop/product/download" class="btn btn-success btn-fill">Download</a>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Product Adding Form</h4>
                <p class="category">Here you can add a new product to sell in your shop</p>
                <?php if(Session::has('Message')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('Message')); ?></label>
                <?php endif; ?>
            </div>
            <div>
                <form action="<?php echo e(url("/shop/product/make")); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Product Name</label>
                                <input type="text" class="form-control" placeholder="Product Name" name="namep" value="<?php echo e(old('namep', '')); ?>">
                                <?php $__errorArgs = ['namep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Product Description</label>
                                <input type="textarea" class="form-control" placeholder="Product Description" name="descp" value="<?php echo e(old('descp', '')); ?>">
                                <?php $__errorArgs = ['descp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Product Type</label>
                                <select name="typep" id="" class="form-control">
                                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=<?php echo e($t->id); ?>><?php echo e($t->Type_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Product Price</label>
                                <input type="text" class="form-control" placeholder="Product Price" name="pricep" value="<?php echo e(old('pricep', '')); ?>">
                                <?php $__errorArgs = ['pricep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Product Stock</label>
                                <input type="text" class="form-control" placeholder="Product Stock" name="stockp" value="<?php echo e(old('stockp', '')); ?>">
                                <?php $__errorArgs = ['stockp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Product Image</label>
                                <input type="file" class="form-control" placeholder="Product Image" name="imagep" value="<?php echo e(old('imagep', '')); ?>">
                                <?php $__errorArgs = ['imagep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn-fill pull-right">Create Product</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Product Restocking Form</h4>
                <p class="category">Here you restock your product in your shop</p>
                <?php if(Session::has('scsr')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scsr')); ?></label>
                <?php endif; ?>
            </div>
            <div>
                <form action="/shop/product/restock" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Product</label>
                                <select name="productr" id="" class="form-control">
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->product_id); ?>"><?php echo e($p->product_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Restock Number</label>
                                <input type="text" class="form-control" placeholder="Restock Number" name="restn" value="<?php echo e(old('restn', '')); ?>">
                                <?php $__errorArgs = ['restn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-info btn-fill pull-right">Restock Product</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal" tabindex="-1" id="modalUpload">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Upload File</h5>
        </div>
        <div class="modal-body">
            <p>Upload your image here</p>
            <form action='<?php echo e(url('shop/product/upload')); ?>' method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="idUploadProduct">
                <div class="col-6">
                    <div class="form-group">
                        <label>Product Image</label>
                        <input type="file" class="form-control" placeholder="Product Image" name="uploadp" value="<?php echo e(old('uploadp', '')); ?>">
                        <?php $__errorArgs = ['uploadp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label for="" class="text-danger"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <button type="submit" class="btn-primary btn btn-fill">Upload</button>
            </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal" tabindex="-1" id="modalEdit">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Edit Product</h5>
        </div>
        <div class="modal-body p-5">
            <form action='<?php echo e(url('shop/product/edit')); ?>' method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="ide" id="idEditProduct">
                <div class="form-group">
                    <label>Product Name</label>
                    <input type="text" id="nameEdit" class="form-control" placeholder="Product Name" name="namee">
                </div>
                <div class="form-group">
                    <label>Product Description</label>
                    <input type="text" id="descEdit" class="form-control" placeholder="Product Description" name="desce">
                </div>
                <div class="form-group">
                    <label>Product Price</label>
                    <input type="text" id="priceEdit" class="form-control" placeholder="Product Price" name="pricee">
                </div>
                <button type="submit" class="btn-primary btn btn-fill">Edit Product</button>
            </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(".btnUpload").on('click', function (e) {
            document.getElementById("idUploadProduct").value = e.target.value;
            $("#modalUpload").modal("show");
        });

        $(".btnEdit").on('click', function (e) {
            document.getElementById('idEditProduct').value = e.target.value;

            $("#modalEdit").modal('show');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/shop/home.blade.php ENDPATH**/ ?>