<?php $__env->startSection('title', 'Master Promo'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">List of Universal Promos</h4>
                <p class="category">Here you can see all of universally available promos</p>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>#</th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Expiration Date</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($p->promo_global_name); ?></td>
                                <td><?php echo e($p->type->promo_type_name); ?></td>
                                <td>
                                    <?php if($p->type->promo_type_name=="Potongan"): ?>
                                        Rp<?php echo e(number_format($p->promo_global_amount,0,',','.')); ?>

                                    <?php else: ?>
                                        <?php echo e($p->promo_global_amount); ?>%
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date('F j, Y',strtotime($p->promo_global_expiredate))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">List of Your Promos</h4>
                <p class="category">Here you can see all of your registered promos, both active and inactive</p>
                <?php if(Session::has('Message')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('Message')); ?></label>
                <?php endif; ?>
                <?php if(Session::has('scsdel')): ?>
                    <label for="" class="text-danger"><?php echo e(Session::get('scsdel')); ?></label>
                <?php endif; ?>
                <?php if(Session::has('scsact')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scsact')); ?></label>
                <?php endif; ?>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped" id="table-promo">
                    <thead>
                        <th>#</th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Expiration Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($p->promo_name); ?></td>
                                <td><?php echo e($p->type->promo_type_name); ?></td>
                                <td>
                                    <?php if($p->type->promo_type_name=="Potongan"): ?>
                                        Rp<?php echo e(number_format($p->promo_amount,0,',','.')); ?>

                                    <?php else: ?>
                                        <?php echo e($p->promo_amount); ?>%
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date('F j, Y',strtotime($p->promo_expiredate))); ?></td>
                                <td>
                                    <?php if($p->promo_status==1): ?>
                                        ACTIVE
                                    <?php else: ?>
                                        NON-ACTIVE
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($p->promo_status==1): ?>
                                        <a href="<?php echo e(url("shop/promo/delete/$p->promo_id")); ?>" class="btn btn-danger">Deactivate</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url("shop/promo/delete/$p->promo_id")); ?>" class="btn btn-success">Activate</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Make a Promo</h4>
                <p class="category">Here you can make a promo applied to your shop.</p>
                <?php if(Session::has('Success')): ?>
                    <p class="text-success"><?php echo e(Session::get('Success')); ?></p>
                <?php endif; ?>
            </div>
            <div>
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>" id="csrf">
                <div class="row-p-3">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Promo Name</label>
                            <input type="text" class="form-control" placeholder="Promo Name" id="namep" name="name" value="<?php echo e(old('name', '')); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row-p-3">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Promo Type</label>
                            <select name="type" id="typep" class="form-control">
                                <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($t->promo_type_id); ?>"><?php echo e($t->promo_type_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row-p-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Promo Amount</label>
                            <input type="text" class="form-control" placeholder="Promo Amount" name="amount" id="amountp" value="<?php echo e(old('amount', '')); ?>">
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Promo Expiration Date</label>
                            <input type="date" class="form-control" placeholder="Promo Expiration Date" name="date" id="datep" value="<?php echo e(old('date', '')); ?>">
                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-info btn-fill pull-right" id="btnCreateP">Create Promo</button>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('#btnCreateP').on("click", function () {
            var name = $("#namep").val();
            var amount = $("#amountp").val();
            var type = $("#typep").val();
            var date = $("#datep").val();

            $.ajax({
                type: "POST",
                url: "/shop/promo/add",
                data: {
                    _token : $("#csrf").val(),
                    type : type,
                    name : name,
                    amount : amount,
                    date : date
                },
                success: function (response) {
                    var res = JSON.parse(response);
                    if (res.statusCode==200) {
                        var p = res.new;
                        var num = res.num;
                        var type = res.type["promo_type_name"];
                        var date = res.date;
                        var n = "";
                        var status = "";
                        var btn = "";

                        var url = res.url;

                        if (type=="Potongan") {
                            n ="Rp" + p["promo_amount"].toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
                        } else {
                            n = (p["promo_amount"].toString()) + "%";
                        }

                        if (p["promo_status"]==1) status = "ACTIVE";
                        else status = "NON-ACTIVE";

                        if (p["promo_status"]==1) btn = "<a href='" + url +"' class='btn btn-danger'>Deactivate</a>";
                        else btn = "<a href='" + url + "' class='btn btn-success'>Activate</a>";

                        // console.log(res.new);
                        $("#table-promo tbody").append("<tr> <td>" + num + "</td><td>" + p["promo_name"] + "</td><td>" + type +"</td><td>"+n+"</td><td>"+date+"</td><td>"+status+"</td><td>"+btn+"</td></tr>");
                    } else {
                        alert("Error inserting new promo !");
                    }
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/shop/promo.blade.php ENDPATH**/ ?>