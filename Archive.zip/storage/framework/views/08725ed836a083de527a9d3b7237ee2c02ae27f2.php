<?php $__env->startSection('title', 'Master Promo'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Daftar Promo Penjual</h4>
                <p class="category">Di sini Anda bisa melihat daftar seluruh promo yang dibuat penjual</p>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Tipe Promo</th>
                        <th>Besar Promo</th>
                        <th>Toko Penjual</th>
                        <th>Tanggal Ekspirasi</th>
                        <th>Status</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $promo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($p->promo_name); ?></td>
                                <td><?php echo e($p->type->promo_type_name); ?></td>
                                <td>
                                    <?php if($p->type->promo_type_name=="Potongan"): ?>
                                        Rp<?php echo e(number_format($p->promo_amount,0,',','.')); ?>

                                    <?php else: ?>
                                        <?php echo e($p->promo_amount); ?>%
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($p->shop->shop_name); ?>

                                </td>
                                <td><?php echo e(date('F j, Y',strtotime($p->promo_expiredate))); ?></td>
                                <td>
                                    <?php if($p->promo_status==1): ?>
                                        AKTIF
                                    <?php else: ?>
                                        NONAKTIF
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="header">
                <p class="category">Di sini Anda bisa melihat daftar seluruh promo yang berlaku di semua toko penjual. Anda bisa melakukan aktivasi atau deaktivasi promo.</p>
                <?php if(Session::has('scsdpact')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scsdpact')); ?></label>
                <?php endif; ?>
                <?php if(Session::has('scspact')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scspact')); ?></label>
                <?php endif; ?>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Tipe Promo</th>
                        <th>Jumlah</th>
                        <th>Tanggal Ekspirasi</th>
                        <th>Status</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $promoGlobal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($p->promo_global_name); ?></td>
                                <td><?php echo e($p->type->promo_type_name); ?></td>
                                <td>
                                    <?php if($p->type->promo_type_name=="Potongan"): ?>
                                        Rp<?php echo e(number_format($p->promo_global_amount,0,',','.')); ?>

                                    <?php else: ?>
                                        <?php echo e($p->promo_global_amount); ?>%
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date('F j, Y',strtotime($p->promo_global_expiredate))); ?></td>
                                <td>
                                    <?php if($p->promo_global_status==1): ?>
                                        AKTIF <br>
                                        <a href="<?php echo e(url('admin/promo/deactivate/'. $p->promo_global_id)); ?>" class="btn btn-danger btn-fill">DEAKTIVASI</a>
                                    <?php else: ?>
                                        NONAKTIF <br>
                                        <a href="<?php echo e(url('admin/promo/activate/'. $p->promo_global_id)); ?>" class="btn btn-success btn-fill">AKTIVASI</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Buat Promo</h4>
                <p class="category">Di sini Anda bisa membuat promo yang akan berlaku untuk semua toko di dalam aplikasi</p>
                <?php if(Session::has('Success')): ?>
                    <p class="text-success"><?php echo e(Session::get('Success')); ?></p>
                <?php endif; ?>
            </div>
            <div>
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Nama Promo</label>
                                <input type="text" class="form-control" placeholder="Nama Promo" name="name" value="<?php echo e(old('name', '')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Promo Type</label>
                                <select name="type" id="" class="form-control">
                                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($t->promo_type_id); ?>"><?php echo e($t->promo_type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Promo Amount</label>
                                <input type="text" class="form-control" placeholder="Promo Amount" name="amount" value="<?php echo e(old('amount', '')); ?>">
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Promo Expiration Date</label>
                                <input type="date" class="form-control" placeholder="Promo Expiration Date" name="date" value="<?php echo e(old('date', '')); ?>">
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn-fill pull-right">Create Promo</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">List of Vouchers</h4>
                <p class="category">Here you can see all of our vouchers, you may make them inactive according to their status</p>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>#</th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Expiration Date</th>
                        <th>Status</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $voucher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($v->voucher_name); ?></td>
                                <td><?php echo e($v->type->promo_type_name); ?></td>
                                <td>
                                    <?php if($v->type->promo_type_name=="Potongan"): ?>
                                        Rp<?php echo e(number_format($v->voucher_amount,0,',','.')); ?>

                                    <?php else: ?>
                                        <?php echo e($v->voucher_amount); ?>%
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(date('F j, Y',strtotime($v->voucher_expiredate))); ?></td>
                                <td>
                                    <?php if($v->voucher_status==1): ?>
                                        ACTIVE <br>
                                        <a href="<?php echo e(url('admin/voucher/deactivate')); ?>" class="btn btn-danger">DEACTIVATE</a>
                                    <?php else: ?>
                                        NON-ACTIVE <br>
                                        <a href="<?php echo e(url('admin/voucher/activate')); ?>" class="btn btn-success">ACTIVATE</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Make a Voucher</h4>
                <p class="category">Here you can make a voucher for the customers</p>
                <?php if(Session::has('Successv')): ?>
                    <p class="text-success"><?php echo e(Session::get('Successv')); ?></p>
                <?php endif; ?>
            </div>
            <div>
                <form action="/admin/voucher/make" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Voucher Name</label>
                                <input type="text" class="form-control" placeholder="Voucher Name" name="namev" value="<?php echo e(old('namev', '')); ?>">
                                <?php $__errorArgs = ['namev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Voucher Type</label>
                                <select name="typev" id="" class="form-control">
                                    <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($t->promo_type_id); ?>"><?php echo e($t->promo_type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Voucher Amount</label>
                                <input type="text" class="form-control" placeholder="Promo Amount" name="amountv" value="<?php echo e(old('amountv', '')); ?>">
                                <?php $__errorArgs = ['amountv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Voucher Expiration Date</label>
                                <input type="date" class="form-control" placeholder="Promo Expiration Date" name="datev" value="<?php echo e(old('datev', '')); ?>">
                                <?php $__errorArgs = ['datev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-info btn-fill pull-right">Create Voucher</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Give Vouchers</h4>
                <p class="category">Here you can give a voucher to the customers</p>
                <?php if(Session::has('Successvg')): ?>
                    <p class="text-success"><?php echo e(Session::get('Successvg')); ?></p>
                <?php endif; ?>
            </div>
            <div>
                <form action="/admin/voucher/give" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Vouchers</label>
                                <select name="voucher" id="" class="form-control">
                                    <?php $__currentLoopData = $voucher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($v->voucher_id); ?>"><?php echo e($v->voucher_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Customers to Give</label>
                                <select name="customer" id="customerSelect" class="form-control" onchange="showDiv('numberInput', this)">
                                    <option value="all">All Customers</option>
                                    <option value="topbuy">Customer with Most Transactions</option>
                                    <option value="random">Random Customers</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Numbers of Vouchers to Give</label>
                                <input type="number" class="form-control" placeholder="Number of voucher(s) to give" name="vnumber" value="<?php echo e(old('number', 1)); ?>" min="1">
                                <?php $__errorArgs = ['vnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4" id="numberInput" style="display:none;">
                            <div class="form-group">
                                <label>Number of Customers to Give Vouchers to</label>
                                <input type="number" class="form-control" placeholder="Number of customers to give" name="number" max="<?php echo e($sumCust); ?>" value="<?php echo e(old('number', '')); ?>" min="1">
                                <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row-p-3">
                        <button type="submit" class="btn btn-info btn-fill pull-right">Give Voucher</button>
                    </div>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function showDiv(divId, element) {
        document.getElementById(divId).style.display = element.value == "all" ? 'none' : 'block';
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/admin/listpromo.blade.php ENDPATH**/ ?>