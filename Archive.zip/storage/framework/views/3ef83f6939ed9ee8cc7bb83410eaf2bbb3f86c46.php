<?php $__env->startSection('title', 'Keranjang'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('scsdel')): ?>
        <label for="" class="text-danger"><?php echo e(Session::get('scsdel')); ?></label>
    <?php endif; ?>
    <?php $__currentLoopData = $cart->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mt-2 px-2">
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card p-3 bg-white mx-4">
                    <div class="about-product text-center mt-2 mb-2"><img src="<?php echo e(asset("storage/imgProduct/product_$product->product_id")); ?>" width="300">
                        <div>
                            <h4><?php echo e($product->product_name); ?></h4>
                        </div>
                    </div>
                    <div class="stats mt-2">
                        <div class="d-flex justify-content-between p-price"><span>Jumlah</span><span><?php echo e($amount[$key]); ?></span></div>
                    </div>
                    <div class="d-flex justify-content-between total font-weight-bold mt-4"><span>Harga</span><span>Rp<?php echo e(number_format($product->product_price,0,',','.')); ?></span></div>
                    <div class="rom mt-2">
                        <a href="<?php echo e(url("customer/cart/delete/$product->product_id")); ?>" class="btn btn-danger">Hapus dari Keranjang</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <hr>

    <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" id="basic-addon1">Alamat Pengantaran</span>
        </div>
        <input type="text" id="alamatp" name="addr" class="form-control" placeholder="Alamat Pengantaran" aria-label="Username" aria-describedby="basic-addon1" value="<?php echo e(old('addr', Auth::user()->customer_address)); ?>">
    </div>

    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <label class="input-group-text" for="inputGroupSelect01">Promo</label>
        </div>
        <select class="custom-select" id="promoGSelect">
            <?php if(count($promoGlobal)): ?>
                <option selected value="0">Pilih...</option>
                <?php $__currentLoopData = $promoGlobal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option type="<?php echo e($p->type->promo_type_name); ?>" amount="<?php echo e($p->promo_global_amount); ?>" value="<?php echo e($p->promo_global_id); ?>"><?php echo e($p->promo_global_name); ?> - <?php echo e($p->type->promo_type_name); ?> <?php if($p->type->promo_type_name=="Diskon"): ?>
                            <?php echo e($p->promo_global_amount); ?>%
                        <?php else: ?>
                            Rp<?php echo e(number_format($p->promo_global_amount,0,',','.')); ?>

                        <?php endif; ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <option selected value="empty">Tidak ada promo !</option>
            <?php endif; ?>
        </select>
    </div>

    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <label class="input-group-text" for="inputGroupSelect01">Promo</label>
        </div>
        <select class="custom-select" id="promoselect">
            <?php if(count($promo)): ?>
                <option selected value="0">Pilih...</option>
                <?php $__currentLoopData = $promo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option type="<?php echo e($p->type->promo_type_name); ?>" amount="<?php echo e($p->promo_amount); ?>" value="<?php echo e($p->promo_id); ?>"><?php echo e($p->promo_name); ?> - <?php echo e($p->type->promo_type_name); ?> <?php if($p->type->promo_type_name=="Diskon"): ?>
                            <?php echo e($p->promo_amount); ?>%
                        <?php else: ?>
                            Rp<?php echo e(number_format($p->promo_amount,0,',','.')); ?>

                        <?php endif; ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <option selected value="empty">Tidak ada promo !</option>
            <?php endif; ?>
        </select>
    </div>

    <div class="input-group mb-3">
        <div class="input-group-prepend">
            <label class="input-group-text" for="inputGroupSelect01">Voucher</label>
        </div>
        <select class="custom-select" id="voucherSelect">
            <option selected value="0">Pilih...</option>
            <?php $__currentLoopData = $voucher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option type="<?php echo e($v->voucher->type->promo_type_name); ?>" amount="<?php echo e($v->voucher->voucher_amount); ?>" value="<?php echo e($v->voucher_customer_id); ?>"><?php echo e($v->voucher->voucher_name); ?> - <?php echo e($v->voucher->type->promo_type_name); ?> <?php if($v->voucher->type->promo_type_name=="Diskon"): ?>
                        <?php echo e($v->voucher->voucher_amount); ?>%
                    <?php else: ?>
                        Rp<?php echo e(number_format($v->voucher->voucher_amount,0,',','.')); ?>

                    <?php endif; ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <hr>

    <div class="row mt-2 px-2" style="display: block">
        <h5>Total</h5>
        <p style="text-align:right">
            <span style="float:left">Harga awal : </span>
            <span id="init"><?php echo e($total); ?></span>
        </p>
    </div>
    <div class="row mt-2 px-2" style="display: block" id="promoGW">

    </div>
    <div class="row mt-2 px-2" style="display: block" id="promoW">

    </div>
    <div class="row mt-2 px-2" style="display: block" id="voucherW">

    </div>
    <div class="row mt-2 px-2" style="display: block" id="totalW">

    </div>
    <div class="row mt-2 px-2" style="display: block" id="totalP">
        <h5 style="text-align:right">
            <span style="float:left">Total : </span>
            <span id="tw"><?php echo e($total); ?></span>
        </h5>
    </div>
    <div class="fixed" style="bottom: 0; width:100%; display:flex; justify-content:center;">
        <button id="btnBayar" class="btn btn-primary">Bayar</button>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        $('#promoGSelect').on('change', function (e) {
            var init = <?php echo e($total); ?>;
            var opt = $(this).find("option:selected");
            var type = opt.attr("type");
            var amount = opt.attr("amount");

            if (type!=null) {
                if (type=="Diskon") {
                    amount = amount*init/100;
                }
                document.getElementById("promoGW").innerHTML = "<p style='text-align:right'><span style='float:left'>Promo : </span><span id='tgw'>".concat(amount).concat("</span></p>");
            } else {
                document.getElementById("promoGW").innerHTML = "";
            }
            var tgw = 0;
            var tpw = 0;
            var tvw = 0;
            if (document.getElementById("tgw")!=null) tgw = document.getElementById("tgw").innerText;
            if (document.getElementById("tpw")!=null) tpw = document.getElementById("tpw").innerText;
            if (document.getElementById("tvw")!=null) tvw = document.getElementById("tvw").innerText;

            var total = parseInt(tgw) + parseInt(tpw) + parseInt(tvw);
            var final = parseInt(init) - parseInt(total);

            document.getElementById("totalW").innerHTML = "<h5 style='text-align:right'><span style='float:left'>Total Potongan : </span><span id='tw'>".concat(total).concat("</span></h5>");
            document.getElementById("totalP").innerHTML = "<h5 style='text-align:right'><span style='float:left'>Total Pembayaran : </span><span id='tw'>".concat(final).concat("</span></h5>");
        });
        $('#promoselect').on('change', function (e) {
            var init = <?php echo e($total); ?>;
            var opt = $(this).find("option:selected");
            var type = opt.attr("type");
            var amount = opt.attr("amount");

            if (type!=null) {
                if (type=="Diskon") {
                    amount = amount*init/100;
                }

                document.getElementById("promoW").innerHTML = "<p style='text-align:right'><span style='float:left'>Promo : </span><span id='tpw'>".concat(amount).concat("</span></p>");
            } else {
                document.getElementById("promoW").innerHTML = "";
            }

            var tgw = 0;
            var tpw = 0;
            var tvw = 0;
            if (document.getElementById("tgw")!=null) tgw = document.getElementById("tgw").innerText;
            if (document.getElementById("tpw")!=null) tpw = document.getElementById("tpw").innerText;
            if (document.getElementById("tvw")!=null) tvw = document.getElementById("tvw").innerText;

            var total = parseInt(tgw) + parseInt(tpw) + parseInt(tvw);
            var final = parseInt(init) - parseInt(total);

            document.getElementById("totalW").innerHTML = "<h5 style='text-align:right'><span style='float:left'>Total Potongan : </span><span id='tw'>".concat(total).concat("</span></h5>");
            document.getElementById("totalP").innerHTML = "<h5 style='text-align:right'><span style='float:left'>Total Pembayaran : </span><span id='tw'>".concat(final).concat("</span></h5>");
        });
        $('#voucherSelect').on('change', function (e) {
            var init = <?php echo e($total); ?>;
            var opt = $(this).find("option:selected");
            var type = opt.attr("type");
            var amount = opt.attr("amount");

            if (type!=null) {
                if (type=="Diskon") {
                    amount = parseInt(amount)*parseInt(init)/100;
                }

                document.getElementById("voucherW").innerHTML = "<p style='text-align:right'><span style='float:left'>Voucher : </span><span id='tvw'>".concat(amount).concat("</span></p>");
            } else {
                document.getElementById("voucherW").innerHTML = "";
            }
            var tgw = 0;
            var tpw = 0;
            var tvw = 0;
            if (document.getElementById("tgw")!=null) tgw = document.getElementById("tgw").innerText;
            if (document.getElementById("tpw")!=null) tpw = document.getElementById("tpw").innerText;
            if (document.getElementById("tvw")!=null) tvw = document.getElementById("tvw").innerText;

            var total = 0 + parseInt(tgw) + parseInt(tpw) + parseInt(tvw);
            var final = parseInt(init) - parseInt(total);

            document.getElementById("totalW").innerHTML = "<h5 style='text-align:right'><span style='float:left'>Total Potongan : </span><span id='tw'>".concat(total).concat("</span></h5>");
            document.getElementById("totalP").innerHTML = "<h5 style='text-align:right'><span style='float:left'>Total Pembayaran : </span><span id='tw'>".concat(final).concat("</span></h5>");
        });

        var payButton = document.getElementById('btnBayar');
            payButton.addEventListener('click', function () {
                var valuepg = $('#promoGSelect').find(":selected").val();
                var valuep = $('#promoselect').find(":selected").val();
                var valuev = $('#voucherSelect').find(":selected").val();
                var alamat = $("#alamatp").val();

                $.ajax({
                    type: "POST",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "<?php echo e(url('customer/bayar')); ?>",
                    data: {
                        _token : "<?php echo e(csrf_token()); ?>",
                        promog : valuepg,
                        promo : valuep,
                        voucher : valuev,
                        alamat : alamat,
                    },
                    success: function (response) {
                        var res = JSON.parse(response);
                        window.snap.pay(res.token);
                    },
                    error:function(xhr, status, error){
                        alert(xhr.responseText);
                    }
                });
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/customer/keranjang.blade.php ENDPATH**/ ?>