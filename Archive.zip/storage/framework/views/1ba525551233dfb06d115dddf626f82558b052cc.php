<?php $__env->startSection('title', 'Hasil Pencarian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <span class="font-weight-bold" style="font-size: 24pt">Cari Toko untuk Belanja !</span>
                </div>
            </div>
            <div class="col-12">
                <form action="/customer/search" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-3 px-3">
                        <div class="col-md-12">
                            <input type="text" name="search" class="form-control" placeholder="Search">
                            <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mt-2">
                            <label class="labels">Pilihan</label><br>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="customRadioInline1" value="nama" name="choice" class="custom-control-input">
                                <label class="custom-control-label" for="customRadioInline1">Nama Toko</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="customRadioInline2" value="lokasi" name="choice" class="custom-control-input">
                                <label class="custom-control-label" for="customRadioInline2">Lokasi Toko</label>
                            </div>
                            <?php $__errorArgs = ['choice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mt-5 text-center">
                        <button class="btn btn-primary profile-button" type="submit">Search</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $list->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j=>$shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card p-3">
                        <div class="card-block">
                            <h4 class="card-title"><?php echo e($shop->shop_name); ?></h4>
                            <h6 class="card-subtitle text-muted mb-3"><?php echo e($shop->shop_address); ?></h6>
                            <h6 class="card-subtitle text-muted mb-3"><?php echo e($reviews[$i][$j]); ?> Bintang</h6>
                            <a href="<?php echo e(url("/customer/toko=$shop->shop_name")); ?>" class="btn btn-primary btn-fill">Lihat Toko</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/customer/search.blade.php ENDPATH**/ ?>