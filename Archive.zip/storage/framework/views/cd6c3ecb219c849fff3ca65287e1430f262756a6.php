<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="card rounded bg-white mt-5 mb-5">
    <div class="row">
        <div class="col-6 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                
                <span class="font-weight-bold"><?php echo e(Auth::user()->customer_name); ?></span>
                <span class="text-black-50"><?php echo e(Auth::user()->customer_username); ?></span>
                <button class="btn btn-primary" id="btnSwitch">Switch Account</button>
                <?php $__errorArgs = ['msgSL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
        </div>
        <div class="col-6">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Profile Settings</h4>
                    <?php if(Session::has('msg')): ?>
                        <label for="" class="text-success"><?php echo e(Session::get('msg')); ?></label>
                    <?php endif; ?>
                </div>
                <form action="/customer/profile/update" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-2">
                        <div class="col-md-12">
                            <label class="labels">Username</label>
                            <input type="text" name="username" class="form-control" placeholder="Username" value="<?php echo e(old('username', Auth::user()->customer_username)); ?>">
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Nama Customer</label>
                            <input type="text" name="name" class="form-control" placeholder="Nama Customer" value="<?php echo e(old('name', Auth::user()->customer_name)); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <label class="labels">Alamat Customer</label>
                            <input type="text" name="address" class="form-control" placeholder="Alamat Customer" value="<?php echo e(old('address', Auth::user()->customer_address)); ?>">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <label class="labels">Nomor Telepon Customer</label>
                            <input type="text" name="phonenumber" class="form-control" placeholder="Nomor Telepon Customer" value="<?php echo e(old('phonenumber', Auth::user()->customer_phonenumber)); ?>">
                            <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <label class="labels">Nomor Rekening Customer</label>
                            <input type="text" name="accountnumber" class="form-control" placeholder="Nomor Rekening Customer" value="<?php echo e(old('accountnumber', Auth::user()->customer_accountnumber)); ?>">
                            <?php $__errorArgs = ['accountnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <label class="labels">Password (Wajib)</label>
                            <input type="password" name="password" class="form-control" placeholder="Password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <label class="labels">Password Baru (Opsional)</label>
                            <input type="password" name="new" class="form-control" placeholder="Password Baru">
                            <?php $__errorArgs = ['new'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12">
                            <label class="labels">Konfirmasi Password Baru</label>
                            <input type="password" name="new-confirm" class="form-control" placeholder="Konfirmasi Password Baru">
                            <?php $__errorArgs = ['new-confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mt-5 text-center">
                        <button class="btn btn-primary profile-button" type="submit">Update Profile</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal" tabindex="-1" id="modalSwitch">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Switch Account</h5>
            </div>
            <div class="modal-body">
                <p>Pilih salah satu akun Anda</p>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url("customer/switch/$account->switch_customer_2")); ?>"><button class="btn btn-primary"><?php echo e($acc[$key]->customer_name); ?></button></a><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button id="btnLogin" class="btn btn-warning mt-4">Login</button>
            </div>
        </div>
    </div>
</div>

<div class="modal" tabindex="-1" id="modalLogin">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Login</h5>
            </div>
            <div class="modal-body">
                <p>Masukkan username dan password Anda</p>
                <form action="/customer/profile/login" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Username</label>
                            <input type="text" name="usernamel" class="form-control" placeholder="Username" value="<?php echo e(old("usernamel", "")); ?>">
                            <?php $__errorArgs = ['usernamel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <label class="labels">Password</label>
                            <input type="password" name="passwordl" class="form-control" placeholder="Password">
                            <?php $__errorArgs = ['passwordl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mt-3 ml-1">
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $("#btnSwitch").on('click', function (e) {
            $("#modalSwitch").modal("show");
        });
        $("#btnLogin").on('click', function (e) {
            $("#modalSwitch").modal("hide");
            $("#modalLogin").modal("show");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/customer/profile.blade.php ENDPATH**/ ?>