<?php $__env->startSection('title', 'Chatroom'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card ml-2" style="width: 90%;">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($room->shop->shop_name); ?></h5>
                <a href="<?php echo e(url("/customer/chat/$room->Chatroom_id")); ?>" class="btn btn-success">Chat</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/customer/chatroom.blade.php ENDPATH**/ ?>