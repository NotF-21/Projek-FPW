<?php $__env->startSection('title', 'Master Shop'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">List of Shops</h4>
                <p class="category">Here you can see all of our registered shops, you may make them inactive according to their status</p>
                <?php if(Session::has('scsact')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scsact')); ?></label>
                <?php elseif(Session::has('scsdact')): ?>
                    <label for="" class="text-danger"><?php echo e(Session::get('scsdact')); ?></label>
                <?php endif; ?>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Alamat</th>
                        <th>Alamat Email</th>
                        <th>Nomor Telepon</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($shop->shop_name); ?></td>
                                <td><?php echo e($shop->shop_username); ?></td>
                                <td><?php echo e($shop->shop_address); ?></td>
                                <td><?php echo e($shop->shop_emailaddress); ?></td>
                                <td><?php echo e($shop->shop_phonenumber); ?></td>
                                <td>
                                    <?php if($shop->shop_status==1): ?>
                                        <a href="/admin/shop/deactivate/<?php echo e($shop->id); ?>" class="btn btn-danger btn-fill">Deaktivasi</a>
                                    <?php else: ?>
                                        <a href="/admin/shop/activate/<?php echo e($shop->id); ?>" class="btn btn-success btn-fill">Aktivasi</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <p class="category">Here you can download all of the data into an Excel spreadsheet</p>
                <a href="/admin/shop/download" class="btn btn-success btn-fill">Download</a>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">List of Shops in Waiting List</h4>
                <p class="category">Here you can see all of currently waiting shops. You may either accept or reject them.</p>
                <?php if(Session::has('scsacpt')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scsacpt')); ?></label>
                <?php elseif(Session::has('scsrjt')): ?>
                    <label for="" class="text-danger"><?php echo e(Session::get('scsrjt')); ?></label>
                <?php endif; ?>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>Key</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $waitinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($shop->shop_name); ?></td>
                                <td><?php echo e($shop->shop_username); ?></td>
                                <td>
                                    <a href="/admin/shop/accept/<?php echo e($shop->id); ?>" class="btn btn-success btn-fill">Terima</a>
                                    <a href="/admin/shop/reject/<?php echo e($shop->id); ?>" class="btn btn-danger btn-fill">Tolak</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/admin/listshop.blade.php ENDPATH**/ ?>