<?php $__env->startSection('title', 'Master User'); ?>

<?php $__env->startSection('message', 'Welcome back, admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">List of Customers</h4>
                <p class="category">Here you can see all of our registered customers</p>
                <?php if(Session::has('scsact')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scsact')); ?></label>
                <?php elseif(Session::has('scsdact')): ?>
                    <label for="" class="text-danger"><?php echo e(Session::get('scsdact')); ?></label>
                <?php endif; ?>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>Key</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Address</th>
                        <th>Phone Number</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cust): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($cust->customer_name); ?></td>
                                <td><?php echo e($cust->customer_username); ?></td>
                                <td><?php echo e($cust->customer_address); ?></td>
                                <td><?php echo e($cust->customer_phonenumber); ?></td>
                                <td>
                                    <?php if($cust->customer_status==1): ?>
                                        <a href="/admin/home/deactivate/<?php echo e($cust->id); ?>" class="btn btn-danger btn-fill">Deactivate</a>
                                    <?php else: ?>
                                        <a href="/admin/home/activate/<?php echo e($cust->id); ?>" class="btn btn-success btn-fill">Activate</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <p class="category">Here you can download all of the data into an Excel spreadsheet</p>
                <a href="/admin/home/download" class="btn btn-success btn-fill">Download</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/admin/listuser.blade.php ENDPATH**/ ?>