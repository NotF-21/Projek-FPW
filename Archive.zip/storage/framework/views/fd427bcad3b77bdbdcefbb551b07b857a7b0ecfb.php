<?php $__env->startSection('title', 'Daftar Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Daftar Transaksi</h4>
                <p class="category">Di sini Anda bisa melihat daftar seluruh transaksi yang berhubungan dengan toko Anda</p>
                <?php if(Session::has('scskirim')): ?>
                    <label for="" class="text-success"><?php echo e(Session::get('scskirim')); ?></label>
                <?php endif; ?>
            </div>
            <div class="content table-responsive table-full-width">
                <table class="table table-hover table-striped">
                    <thead>
                        <th>#</th>
                        <th>Nomor Nota</th>
                        <th>Tanggal Transaksi</th>
                        <th>Customer</th>
                        <th>Total</th>
                        <th>Status Pembayaran</th>
                        <th>Status Transaksi</th>
                        <th>Alamat Pengiriman</th>
                        <th>Detail</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($trans->invoice_number); ?></td>
                                <td><?php echo e(date('F j, Y',strtotime($trans->trans_date))); ?></td>
                                <td><?php echo e($trans->customer_name); ?></td>
                                <td>Rp<?php echo e(number_format($trans->trans_total,0,',','.')); ?></td>
                                <td><?php if($trans->payment_status=="paid"): ?>
                                    Sudah Dibayar
                                    <?php elseif($trans->payment_status=="expired"): ?>
                                    Kedaluwarsa
                                    <?php else: ?>
                                    Gagal Dibayar
                                <?php endif; ?></td>
                                <td>
                                    <?php if($trans->order_status=="waiting"): ?>
                                    Menunggu
                                    <?php elseif($trans->order_status=="confirmed"): ?>
                                    Terkonfirmasi
                                    <?php elseif($trans->order_status=="sent"): ?>
                                    Dalam Pengiriman
                                    <?php elseif($trans->order_status=="received"): ?>
                                    Sudah Sampai
                                    <?php else: ?>
                                    Dibatalkan
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($trans->shipping_address); ?></td>
                                <td>
                                    <button tag="<?php echo e($trans->invoice_number); ?>" class="btn btn-fill btn-primary btn-detail">Detail</button>
                                </td>
                                <td>
                                    <?php if($trans->order_status=="confirmed"): ?>
                                        <a href="/shop/kirim/<?php echo e($trans->invoice_number); ?>" class="btn btn-fill btn-primary">Kirim</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Download Daftar Penjualan</h4>
                <p class="category">Di sini Anda bisa men-download daftar transaksi di aplikasi ini berdasarkan waktu transaksi</p>
            </div>
            <div>
                <form action="/shop/penjualan/download" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row-p-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Tanggal Awal</label>
                                <input type="date" class="form-control" name="first" placeholder="Tanggal awal">
                                <?php $__errorArgs = ['first'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Tanggal Akhir</label>
                                <input type="date" class="form-control" name="last" placeholder="Tanggal akhir">
                                <?php $__errorArgs = ['last'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-fill btn-primary pull-right">Download</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Download Daftar Sales</h4>
                <p class="category">Di sini Anda bisa men-download daftar transaksi di aplikasi ini berdasarkan produk yang dijual</p>
            </div>
            <div>
                <form action="/shop/sales/download" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row-p-3">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Produk</label>
                                <select name="product" id="" class="form-control">
                                    <option value="0" disabled selected>Pilih---</option>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->product_id); ?>"><?php echo e($p->product_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-fill btn-primary pull-right">Download</button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal modalTrans" tabindex="-1" id="modal_<?php echo e($t->invoice_number); ?>">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Detail Transaksi</h5>
                    </div>
                    <div class="modal-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th>Harga</th>
                                    <th>Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $details[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($detail->product->product_name); ?></td>
                                        <td>Rp<?php echo e(number_format($detail->product->product_price,0,',','.')); ?></td>
                                        <td><?php echo e($detail->product_number); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                    </div>
                    <div class="modal-footer">
                        <p>Promo yang dipakai : <?php if($promo[$key]=="empty"): ?>
                            Tidak ada
                            <?php else: ?>
                            <?php echo e($promo[$key]->promo_name); ?>

                        <?php endif; ?></p><br>
                        <p>Promo yang dipakai : <?php if($pg[$key]=="empty"): ?>
                            Tidak ada
                            <?php else: ?>
                            <?php echo e($pg[$key]->promo_global_name); ?>

                        <?php endif; ?></p><br>
                        <p>Voucher yang dipakai : <?php if($voucher[$key]=="empty"): ?>
                            Tidak ada
                            <?php else: ?>
                            <?php echo e($voucher[$key]->voucher_name); ?>

                        <?php endif; ?></p><br>
                        <button type="button" class="btn btn-danger btn-fill" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(".btn-detail").on("click", function (e) {
        var id = "#modal_" + $(this).attr("tag");
        $(id).modal("show");
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/shop/trans.blade.php ENDPATH**/ ?>