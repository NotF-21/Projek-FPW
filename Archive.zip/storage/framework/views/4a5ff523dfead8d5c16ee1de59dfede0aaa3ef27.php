<?php $__env->startSection('title', 'Chatroom'); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card ml-2" style="width: 90%;">
            <div class="header">
                <h4 class="title"><?php echo e($room->customer->customer_name); ?></h4>
            </div>
            <div class="card-body">
                <a href="<?php echo e(url("shop/chat/$room->Chatroom_id")); ?>" class="btn btn-primary btn-fill pull-right">Chat</a>
                <div class="clearfix"></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/shop/chatroom.blade.php ENDPATH**/ ?>