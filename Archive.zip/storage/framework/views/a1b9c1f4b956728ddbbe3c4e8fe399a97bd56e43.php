<?php $__env->startSection('title', 'Daftar Promo'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <span class="font-weight-bold" style="font-size: 24pt">Promo yang berlaku sekarang !</span>
                </div>
            </div>
            <div class="col-12 p-4">
                <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-md-10 mb-3">
                            <div class="card p-3">
                                <div class="card-block">
                                    <h4 class="card-title"><?php echo e($p->promo_global_name); ?></h4>
                                    <h6 class="card-subtitle text-muted mb-3"><?php echo e($p->type->promo_type_name); ?> <?php if($p->type->promo_type_name=="Potongan"): ?>
                                        Rp<?php echo e(number_format($p->promo_global_amount,0,',','.')); ?>

                                    <?php else: ?>
                                        <?php echo e($p->promo_global_amount); ?>%
                                    <?php endif; ?></h6>
                                    <h6 class="card-subtitle mb-3"><?php echo e(date('F j, Y',strtotime($p->promo_global_expiredate))); ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="card rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <span class="font-weight-bold" style="font-size: 24pt">Toko yang memiliki promo sekarang !</span>
                </div>
            </div>
            <div class="col-12 p-4">
                <?php $__currentLoopData = $shops->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="card p-3">
                                    <div class="card-block">
                                        <h4 class="card-title"><?php echo e($shop->shop_name); ?></h4>
                                        <h6 class="card-subtitle text-muted mb-3"><?php echo e($shop->shop_address); ?></h6>
                                        <a href="<?php echo e(url("/customer/toko=$shop->shop_name")); ?>" class="btn btn-primary btn-fill">Lihat Toko</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="card rounded bg-white mt-5 mb-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                    <span class="font-weight-bold" style="font-size: 24pt">Voucher yang ada sekarang !</span>
                </div>
            </div>
            <div class="col-12 p-4">
                <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-md-10 mb-3">
                            <div class="card p-3">
                                <div class="card-block">
                                    <h4 class="card-title"><?php echo e($v->voucher->voucher_name); ?></h4>
                                    <h6 class="card-subtitle text-muted mb-3"><?php echo e($v->voucher->type->promo_type_name); ?> <?php if($v->voucher->type->promo_type_name=="Potongan"): ?>
                                        Rp<?php echo e(number_format($v->voucher->voucher_amount,0,',','.')); ?>

                                    <?php else: ?>
                                        <?php echo e($v->voucher->voucher_amount); ?>%
                                    <?php endif; ?></h6>
                                    <h6 class="card-subtitle mb-3"><?php echo e(date('F j, Y',strtotime($v->voucher->voucher_expiredate))); ?></h6>
                                    <?php if($warning[$key]=="yes"): ?>
                                        <h6 class="card-subtitle text-muted text-danger mb-3">Voucher ini akan berakhir kurang dari 2 minggu lagi !</h6>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/marcellreynaldo/Desktop/Kuliah/Semester_5/Software Development Project/projek/projek_sdp/resources/views/customer/promo.blade.php ENDPATH**/ ?>